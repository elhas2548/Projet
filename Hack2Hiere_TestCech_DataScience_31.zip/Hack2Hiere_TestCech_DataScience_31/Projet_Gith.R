#Instalation des packages

library(shiny)
library(ggplot2)
library(dplyr)
library(DT)
library(corrplot)
library(caret)
library(pROC)
# Charger les données du German Credit Data 
data<- read.csv("C:/Users/USER/Desktop/german_credit_data.csv")
# Convertir les variables catégoriques en numériques pour calculer les corrélations
num_data <- data %>%
  select_if(is.numeric)
cor_matrix <- cor(num_data, use = "complete.obs")
corrplot(cor_matrix, method = "circle")
# UI pour l'application Shiny
ui <- fluidPage(
  titlePanel("Tableau de bord interactif - Scoring de crédit"),
  
  sidebarLayout(
    sidebarPanel(
      selectInput("x_var", "Credit.amount:", 
                  choices = names(data), selected = "Age"),
      selectInput("y_var", "Credit.amount:", 
                  choices = names(data), selected = "Credit.amount"),
      checkboxInput("show_data", "Afficher les données", value = FALSE)
    ),
    
    mainPanel(
      plotOutput("scatterPlot"),
      dataTableOutput("dataTable")
    )
  )
)
# Serveur pour l'application Shiny
server <- function(input, output) {
  
  # Graphique de dispersion
  output$scatterPlot <- renderPlot({
    ggplot(data, aes_string(x = input$x_var, y = input$y_var, color = "Default")) +
      geom_point(alpha = 0.7) +
      theme_minimal() +
      labs(title = paste("Relation entre", input$x_var, "et", input$y_var),
           x = input$x_var, y = input$y_var)
  })
  # Affichage des données
  output$dataTable <- renderDataTable({
    if (input$show_data) {
      datatable(data)
    }
  }) 
  
}

# Lancer l'application Shiny
shinyApp(ui = ui, server = server)
# Transformation des variables catégoriques
data$Default <- as.factor(data$Sex)
# Division des données en ensemble d'entraînement/test
set.seed(123)
trainIndex <- createDataPartition(data$Default, p = 0.7, list = FALSE)
trainData <- data[trainIndex, ]
testData <- data[-trainIndex, ]
# Modèle de régression logistique
model <- glm(Default ~ Age + Credit.amount + Duration + Purpose, 
             data = trainData, family = "binomial")
# Évaluation sur l'ensemble de test
pred_probs <- predict(model, newdata = testData, type = "response")
pred_classes <- ifelse(pred_probs > 0.5, 1, 0)
# Performance du modèle
confusionMatrix(as.factor(pred_classes), testData$Default)
# S'assurer que les niveaux sont identiques
testData$Default <- factor(testData$Default, levels = c(0, 1))
pred_classes <- factor(pred_classes, levels = c(0, 1))
table(pred_classes)
table(testData$Default)
pred_classes <- factor(pred_classes, levels = levels(testData$Default))
confusionMatrix(pred_classes, testData$Default)
# Courbe ROC
roc_curve <- roc(testData$Default, pred_probs)
plot(roc_curve, col = "red")
auc(roc_curve)